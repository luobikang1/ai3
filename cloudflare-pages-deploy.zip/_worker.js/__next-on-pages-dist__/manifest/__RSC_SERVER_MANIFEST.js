var e={},E=(o,_,n)=>(e.__RSC_SERVER_MANIFEST=o.__RSC_SERVER_MANIFEST=`{
  "node": {},
  "edge": {},
  "encryptionKey": "+mrwEWYoSSLoZTQU5DVQoYE24TO47MHygueeNO87d2Y="
}`,e);export{E as __getNamedExports};
